package pl.lodz.p.library.adapters.soap.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;
import pl.lodz.p.library.adapters.soap.dto.UserDTO;

@XmlType(name = "librarianDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class LibrarianDTO extends UserDTO {

    public LibrarianDTO() {
    }

    public LibrarianDTO(String id, String login, String email, int age, boolean active, String type) {
        super(id, login, email, age, active, type);
    }
}
