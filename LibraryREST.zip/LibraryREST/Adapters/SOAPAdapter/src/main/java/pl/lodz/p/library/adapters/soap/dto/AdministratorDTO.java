package pl.lodz.p.library.adapters.soap.dto;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlType;

@XmlType(name = "administratorDTO")
@XmlAccessorType(XmlAccessType.FIELD)
public class AdministratorDTO extends UserDTO {

    public AdministratorDTO() {
    }

    public AdministratorDTO(String id, String login, String email, int age, boolean active, String type) {
        super(id, login, email, age, active, type);
    }
}
